# TickerBase Reference

::: yfinance.base.TickerBase