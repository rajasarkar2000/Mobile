# Ticker

::: yfinance.ticker.Ticker